import subprocess
import time

def restart_script(script_path, delay=120):
  """Перезапускает скрипт с заданной задержкой.

  Args:
    script_path: Путь к файлу скрипта.
    delay: Задержка перед перезапуском в секундах.
  """

  while True:
    try:
      # Запускаем скрипт
      subprocess.Popen(["python", script_path])
      # Ожидаем заданную задержку
      time.sleep(delay)
    except KeyboardInterrupt:
      print("Завершение перезапуска...")
      break

# Замените "your_script.py" на путь к вашему скрипту
restart_script("run.py")